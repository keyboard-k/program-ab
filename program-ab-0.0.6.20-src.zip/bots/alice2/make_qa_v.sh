#
dir=`pwd`
botname=$(basename $dir)
echo creating QA_V directory for $botname
rm -rf qa_v
mkdir qa_v
cp aiml/*.aiml qa_v
rm qa_v/triple.aiml
rm qa_v/test.aiml
rm qa_v/rsvp.aiml
cp aiml/zpand-virtualassistant.txt qa_v/zpand-virtualassistant.aiml
cp maps_pand/* qa_v
cp sets_pand/* qa_v
cp config/$botname.properties qa_v
cp config/$botname.pdefaults qa_v
sed -i 's/learnf>/learn>/g' qa_v/*.aiml
rm -rf c:/alice/aiml-en-us-foundation-alice2v
mkdir c:/alice/aiml-en-us-foundation-alice2v
cp qa/* c:/alice/aiml-en-us-foundation-alice2v
zip aiml-en-us-foundation-alice2v.zip qa_v/*
scp aiml-en-us-foundation-alice2v.zip drwallace@callmom.pandorabots.com:/home/pandora/static/bots/aiml-en-us-foundation-alice2v.zip
scp qa/* drwallace@callmom.pandorabots.com:/home/pandora/static/bots/aiml-en-us-foundation-alice2v







