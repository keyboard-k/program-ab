#
export appzero=callmom.pandorabots.com:58300
export username=drwallace
export password=chat2bots
dir=`pwd`
botname=$(basename $dir)
echo uploading $botname
#export botname=alice2
hack="--data-binary @/dev/null"

for i in config/properties.json ; do
    echo upload properties file $i
    curl -b cookie.jar -X PUT --data-binary @$i http://$appzero/bot/$username/$botname/properties
done
