export appzero=callmom.pandorabots.com:58300
export botname=alice2
export account=drwallace
export password=chat2bots
set -x

rm cookie.jar

# log in
curl -v -c cookie.jar -X POST -F username=$account -F password=$password http://$appzero/account/signIn


while read line           
do           
input=$line
inputfield="input=$input"
echo
echo $input
echo 
response=`curl -v -b cookie.jar -X POST -F "$inputfield" http://$appzero/talk/$account/$botname`
echo $response | awk -F [ '{print $2}' | awk -F ] '{print $1}'
done < sample.txt
