rm ../maps_pand/*
for i in *.txt; do
 echo convert $i
 sname=${i%.*}
 pname=../maps_pand/$sname.map
 echo $pname
 echo [ > $pname
# reverse the order of lines for gendername
 tac $i | awk -F ":" '{print "[\""$1"\",\""$2"\"],"}' >> $pname
 echo [\"fooz\",\"barz\"]] >> $pname
done
