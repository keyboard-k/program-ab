rm properties.json
rm pdefaults.json
i=predicates.txt
echo convert $i
pname=alice2.pdefaults
echo $pname
echo [ > $pname
grep . $i | awk -F ":" '{print "[\""$1"\",\""$2"\"],"}' >> $pname
echo [\"fooz\",\"barz\"]] >> $pname
i=properties.txt
echo convert $i
pname=alice2.properties
echo $pname
echo [ > $pname
grep . $i | awk '{$2=substr($2,2); print "[\""$1"\",\""$2"\"],"}' FPAT='(^[^:]+)|(:.*)' | fgrep -v http >> $pname
echo [\"fooz\",\"barz\"]] >> $pname

