rm ../sets_pand/*
for i in *.txt; do
 echo convert $i
 sname=${i%.*}
 pname=../sets_pand/$sname.set
 echo $pname
 echo [ > $pname
 awk '{print "\""$0"\","}' < $i >> $pname
 echo \"fooz\"] >> $pname
done
