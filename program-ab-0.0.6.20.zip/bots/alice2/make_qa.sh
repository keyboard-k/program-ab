#
dir=`pwd`
botname=$(basename $dir)
echo creating QA directory for $botname
rm -rf qa
mkdir qa
cp aiml/*.aiml qa
rm qa/triple.aiml
rm qa/test.aiml
rm qa/rsvp.aiml
cp aiml/zpand-webbot.txt qa/zpand-webbot.aiml
cp maps_pand/* qa
cp sets_pand/* qa
cp config/$botname.properties qa
cp config/$botname.pdefaults qa
sed -i 's/learnf>/learn>/g' qa/*.aiml
rm -rf c:/alice/aiml-en-us-foundation-alice2
mkdir c:/alice/aiml-en-us-foundation-alice2
cp qa/* c:/alice/aiml-en-us-foundation-alice2
zip aiml-en-us-foundation-alice2.zip qa/*
scp aiml-en-us-foundation-alice2.zip drwallace@callmom.pandorabots.com:/home/pandora/static/bots/aiml-en-us-foundation-alice2.zip
scp qa/* drwallace@callmom.pandorabots.com:/home/pandora/static/bots/aiml-en-us-foundation-alice2

