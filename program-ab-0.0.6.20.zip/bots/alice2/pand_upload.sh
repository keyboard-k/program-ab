#
if [ $# -eq 3 ]
then
export appzero=$1
export username=$2
export password=$3
else
export appzero=callmom.pandorabots.com:58300
export username=drwallace
export password=chat2bots
fi
echo $appzero $username $password
dir=`pwd`
botname=$(basename $dir)
echo uploading $botname
#export botname=alice2
hack="--data-binary @/dev/null"

# log in
curl -c cookie.jar -X POST -F username=$username -F password=$password http://$appzero/account/signIn

# delete bot if it exists
curl -b cookie.jar -X DELETE http://$appzero/bot/$username/$botname

# create bot
curl -b cookie.jar -X PUT $hack http://$appzero/bot/$username/$botname

sed -i 's/learnf>/learn>/g' aiml/*.aiml

rm aiml/learnf.aiml
mv aiml/zpand-webbot.txt aiml/zpand-webbot.aiml

if [ $appzero=='callmom.pandorabots.com:58300' ]
then
echo "JKF"
cp aiml/sraix_combine_drwallace.txt aiml/sraix_combine.aiml
else
echo "DF"
cp aiml/sraix_combine_admin.txt aiml/sraix_combine.aiml
fi


for i in aiml/*.aiml ; do
    echo upload file $i as $(basename $i)
    curl -b cookie.jar -X PUT --data-binary @$i http://$appzero/bot/$username/$botname/file/$(basename $i)
done

mv aiml/zpand-webbot.aiml aiml/zpand-webbot.txt

sed -i 's/learn>/learnf>/g' aiml/*.aiml
cp aiml/sraix_combine_drwallace.txt aiml/sraix_combine.aiml

for i in maps_pand/*.map ; do
    xx=$(basename $i)
    xx=${xx#map_pand/}
    xx=${xx%.map}
    echo upload map file $i as $xx
    curl -b cookie.jar -X PUT --data-binary @$i http://$appzero/bot/$username/$botname/map/$xx
done

for i in sets_pand/*.set ; do
    xx=$(basename $i)
    xx=${xx#sets_pand/}
    xx=${xx%.set}
    echo upload set file $i as $xx
    curl -b cookie.jar -X PUT --data-binary @$i http://$appzero/bot/$username/$botname/set/$xx
done

for i in config/alice2.properties ; do
    echo upload properties file $i
    curl -b cookie.jar -X PUT --data-binary @$i http://$appzero/bot/$username/$botname/properties
done

for i in config/alice2.pdefaults ; do
    echo upload pdefaults file $i
    curl -b cookie.jar -X PUT --data-binary @$i http://$appzero/bot/$username/$botname/pdefaults
done

# compile`
curl -v -b cookie.jar -X GET http://$appzero/bot/$username/$botname/verify



#make public
curl -b cookie.jar -X POST -F open=true http://$appzero/bot/$username/$botname
