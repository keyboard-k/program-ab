export appzero=callmom.pandorabots.com:58300
export username=rich
export password=alicebot
dir=`pwd`
botname=$(basename $dir)
echo chatting to $botname as $username
echo

#export botname=alice2
hack="--data-binary @/dev/null"

# log in
# curl -c cookie2.jar -X POST -F username=$username -F password=$password http://$appzero/account/signIn

# talk
cat c:/ab/data/normal.random2.txt | awk '{print "\necho "$0"\ncurl -v -b cookie2.jar -X POST -F '\''input="$0"'\'' http://callmom.pandorabots.com:58300/talk/drwallace/alice2 | awk -F [ '\''{print $2}'\'' | awk -F ] '\''{print $1}'\''\necho"}' > autochat2.sh

./autochat2.sh


